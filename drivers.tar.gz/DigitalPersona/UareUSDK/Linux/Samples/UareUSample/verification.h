/* 
 * Copyright (C) 2011, Digital Persona, Inc.
 *
 * This file is a part of sample code for the UareU SDK 2.x.
 */

#pragma once

#include <dpfpdd.h>

void Verification(DPFPDD_DEV hReader);
